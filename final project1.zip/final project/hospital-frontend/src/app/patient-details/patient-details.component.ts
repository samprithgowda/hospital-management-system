import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PatientService } from '../patient.service';
import { Patients } from '../patients';

@Component({
  selector: 'app-patient-details',
  templateUrl: './patient-details.component.html',
  styleUrls: ['./patient-details.component.css']
})
export class PatientDetailsComponent implements OnInit {
  pid!: number;
  
  patients ! : Patients;
  
  constructor(private pats : PatientService , 
    private Route :ActivatedRoute) { }


  ngOnInit(): void {
    this.pid = this.Route.snapshot.params['pid'];

    this.patients = new Patients();
    this.pats.getPatientById(this.pid).subscribe(data =>{
    this.patients = data;
    });
  }

}
