import { Component, OnInit } from '@angular/core';
import { Doctor } from '../doctor';
import { DocterService } from '../docter.service';
import { ActivatedRoute, Router, Routes } from '@angular/router';

@Component({
  selector: 'app-update-doctor',
  templateUrl: './update-doctor.component.html',
  styleUrls: ['./update-doctor.component.css']
})
export class UpdateDoctorComponent implements OnInit {
  docid!: number;
  doctor : Doctor = new Doctor();
  constructor(private Docts : DocterService , private Route :ActivatedRoute, private router : Router) { }

  ngOnInit(): void {
    this.docid = this.Route.snapshot.params['docid'];
    this.Docts.getDoctorById(this.docid).subscribe(data =>{
      this.doctor =data;
    },error => console.error(error));
    
  }

  onSubmit(){
    this.Docts.updateDoctor(this.docid,this.doctor).subscribe( data =>{
      this.goToDoctorlist();
    },error=>console.error(error));
  }
  goToDoctorlist() {
    this.router.navigate(['/dotors']);
  }
}
