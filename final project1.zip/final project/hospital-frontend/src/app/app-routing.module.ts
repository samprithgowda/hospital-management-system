import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreateDoctorComponent } from './create-doctor/create-doctor.component';
import { DoctorDetailsComponent } from './doctor-details/doctor-details.component';
import { DoctorListComponent } from './doctor-list/doctor-list.component';
import { UpdateDoctorComponent } from './update-doctor/update-doctor.component';
import { HomeComponent } from './home/home.component';
import { PatientListComponent } from './patient-list/patient-list.component';
import { CreatePatientComponent } from './create-patient/create-patient.component';
import { UpdatePatientComponent } from './update-patient/update-patient.component';
import { PatientDetailsComponent } from './patient-details/patient-details.component';



const routes: Routes = [
  {path: 'home', component: HomeComponent},

  {path: 'doctors', component: DoctorListComponent},
{path: 'create-doctor', component: CreateDoctorComponent},
{path: '', redirectTo: 'Doctor', pathMatch: 'full'},
{path: 'update-doctor/:docid', component: UpdateDoctorComponent},
{path: 'doctor-details/:docid', component: DoctorDetailsComponent},


{path: 'patients', component:PatientListComponent },
{path: 'create-patient', component: CreatePatientComponent},
{path: '', redirectTo: 'Patients', pathMatch: 'full'},
{path: 'update-patient/:pid', component: UpdatePatientComponent},
{path: 'patient-details/:pid', component: PatientDetailsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
