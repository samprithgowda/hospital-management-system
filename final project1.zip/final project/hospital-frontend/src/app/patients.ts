export class Patients {
    pid !: number;
    pname ! : String;
    page !: number;
    pgender ! : String;
    dateOfVisit !: String;
    doctorid ={
        
        name : String,
        docid : String
    }
}
