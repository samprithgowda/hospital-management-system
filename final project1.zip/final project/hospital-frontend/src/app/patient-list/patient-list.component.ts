import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PatientService } from '../patient.service';
import { Patients } from '../patients';

@Component({
  selector: 'app-patient-list',
  templateUrl: './patient-list.component.html',
  styleUrls: ['./patient-list.component.css']
})
export class PatientListComponent implements OnInit {
  pid!: number;
  patient : Patients = new Patients();
  patients ! : Patients[];
  dtOptions: any = {};
  constructor(private pats : PatientService , private Route :ActivatedRoute, private router : Router) { }

  ngOnInit(): void {
    this.getPatient();
     
    setTimeout(()=>{                          
     $('#datatableexample').DataTable( {
       pagingType: 'full_numbers',
       pageLength: 5,
       processing: true,
       lengthMenu : [5, 10, 25],
       order:[[1,"desc"]]
   } );
   }, 200);
 }
 PatientDetail(pid :number){
   this.router.navigate(['patient-details',pid]);
 }

 

 UpdatePatient(pid : number){
   this.router.navigate(['update-patient',pid]);
 }
deletePatient(pid : number){
 this.pats.deletePatient(pid).subscribe(data=>{
   console.log(data);
   this.getPatient();
 })

}

 private getPatient(){
   this.pats.getPatientList().subscribe((res : any) => {
     this.patients = res;
     
     
   });
 }
}
