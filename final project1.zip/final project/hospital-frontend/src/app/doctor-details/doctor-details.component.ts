import { Component, OnInit } from '@angular/core';
import { Doctor } from '../doctor';
import { Router, ActivatedRoute } from '@angular/router';
import { DocterService } from '../docter.service';

@Component({
  selector: 'app-doctor-details',
  templateUrl: './doctor-details.component.html',
  styleUrls: ['./doctor-details.component.css']
})
export class DoctorDetailsComponent implements OnInit {
 docid!: number;
 doctor!: Doctor;
  constructor(private router : ActivatedRoute , private docs : DocterService) { }

  ngOnInit(): void {
    this.docid=this.router.snapshot.params['docid'];


    this.doctor = new Doctor();
    this.docs.getDoctorById(this.docid).subscribe(data => {
      this.doctor =data;
    })
  }

}
