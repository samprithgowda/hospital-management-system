import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Doctor } from './doctor';

@Injectable({
  providedIn: 'root'
})
export class DocterService {

  private baseUrl = 'http://localhost:8080/api/v1/doctors';
  constructor(private httpClient : HttpClient) { }

  


  getDoctorList() : Observable<Doctor[]>{
    return this.httpClient.get<Doctor[]>(`${this.baseUrl}`);
  }

  createDoctor(doct : Doctor) : Observable<Object>{
    return this.httpClient.post(`${this.baseUrl}`, doct);
  }

  getDoctorById(docid : number):Observable<any>{
    return this.httpClient.get<any>(`${this.baseUrl}/${docid}`);
  }

  updateDoctor(docid:number,doct :Doctor): Observable<object>{
    return this.httpClient.put(`${this.baseUrl}/${docid}`,doct);
  }
  deleteDoctor(docid : number) : Observable<object>{
    return this.httpClient.delete(`${this.baseUrl}/${docid}`);
  }
}
