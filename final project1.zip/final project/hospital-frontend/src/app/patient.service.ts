import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Patients } from './patients';

@Injectable({
  providedIn: 'root'
})
export class PatientService {
  static getPatientList(): any {
    throw new Error('Method not implemented.');
  }
  static getObservableValue() {
    throw new Error('Method not implemented.');
  }
  static getPromiseValue() {
    throw new Error('Method not implemented.');
  }
  private baseUrl = 'http://localhost:8080/api/v1/patients';
  constructor(private httpClient : HttpClient) { }

  


  getPatientList() : Observable<Patients[]>{
    return this.httpClient.get<Patients[]>(`${this.baseUrl}`);
  }

  createPatient(pati : Patients) : Observable<Object>{
    return this.httpClient.post(`${this.baseUrl}`, pati);
  }

  getPatientById(Pid : number):Observable<any>{
    return this.httpClient.get<any>(`${this.baseUrl}/${Pid}`);
  }

  updatePatient(Pid:number,doct :Patients): Observable<object>{
    return this.httpClient.put(`${this.baseUrl}/${Pid}`,doct);
  }
  deletePatient(Pid : number) : Observable<object>{
    return this.httpClient.delete(`${this.baseUrl}/${Pid}`);
  }
}
