import { Component, OnInit } from '@angular/core';
import { Doctor } from '../doctor';
import { DocterService } from '../docter.service';

import { Router } from '@angular/router';
declare let $: any;


@Component({
  selector: 'app-doctor-list',
  templateUrl: './doctor-list.component.html',
  styleUrls: ['./doctor-list.component.css']
})
export class DoctorListComponent implements OnInit {
  doctor : Doctor =new Doctor();
   doctors!: Doctor[];
   docid!: number;
   dtOptions: any = {};
  constructor(private docs :DocterService , private router : Router) { }

  ngOnInit(): void {
    
     this.getDoctors();
     
     setTimeout(()=>{                          
      $('#datatableexample').DataTable( {
        pagingType: 'full_numbers',
        pageLength: 5,
        processing: true,
        lengthMenu : [5, 10, 25],
        order:[[1,"desc"]]
    } );
    }, 200);
  }
  DoctorDetail(docid :number){
    this.router.navigate(['doctor-details',docid]);
  }

  

  UpdateDoctor(docid : number){
    this.router.navigate(['update-doctor',docid]);
  }
 deleteDoctor(docid : number){
  this.docs.deleteDoctor(docid).subscribe(data=>{
    console.log(data);
    this.getDoctors();
  })

}

  private getDoctors(){
    this.docs.getDoctorList().subscribe((res : any) => {
      this.doctors = res;
      
      
    });
  }
}

 

  
