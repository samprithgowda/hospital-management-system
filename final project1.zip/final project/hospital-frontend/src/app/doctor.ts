export class Doctor {
    docid !: number;
    name !: string;
    gender !: string;
    specialist !: string;
}
