import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PatientService } from '../patient.service';
import { Patients } from '../patients';

@Component({
  selector: 'app-update-patient',
  templateUrl: './update-patient.component.html',
  styleUrls: ['./update-patient.component.css']
})
export class UpdatePatientComponent implements OnInit {
  pid!: number;
  patient : Patients = new Patients();
  constructor(private pats : PatientService , private Route :ActivatedRoute, private router : Router) { }

  ngOnInit(): void {
    this.pid = this.Route.snapshot.params['pid'];
    this.pats.getPatientById(this.pid).subscribe(data =>{
      this.patient =data;
    },error => console.error(error));
    
  }

  onSubmit(){
    this.pats.updatePatient(this.pid,this.patient).subscribe( data =>{
      this.goTopatientlist();
    },error=>console.error(error));
  }
  goTopatientlist() {
    this.router.navigate(['/patients']);
  }
}
