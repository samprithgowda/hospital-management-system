import { Patients } from './patients';

describe('Patients', () => {
  it('should create an instance', () => {
    expect(new Patients()).toBeTruthy();
  });
});
